import "./PlayerCard.css";

export default function PlayerCard({ name, symbol, active = false }) {
  return (
    <article className={`player-card ${active ? "player-card--active" : ""}`}>
      <span className="player-card__symbol">{symbol}</span>
      <span className="player-card__name">{name}</span>
      {active && <span className="player-card__status">Ваш хід</span>}
    </article>
  );
}
