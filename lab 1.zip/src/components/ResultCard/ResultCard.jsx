import "./ResultCard.css";

export default function ResultCard({ winner, scoreX, scoreO }) {
  return (
    <article className="result-card">
      <div className="result-card__icon">🏆</div>
      <p className="result-card__label">Переможець</p>
      <h1>{winner}</h1>

      <div className="score">
        <span>X</span>
        <strong>{scoreX} : {scoreO}</strong>
        <span>O</span>
      </div>
    </article>
  );
}
