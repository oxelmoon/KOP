import "./Button.css";

export default function Button({ children, variant = "primary" }) {
  return (
    <button className={`button button--${variant}`} type="button">
      {children}
    </button>
  );
}
