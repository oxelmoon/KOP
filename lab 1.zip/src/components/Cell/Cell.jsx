import "./Cell.css";

export default function Cell({ value = "" }) {
  return (
    <button className="cell" type="button" aria-label="Клітинка">
      {value}
    </button>
  );
}
