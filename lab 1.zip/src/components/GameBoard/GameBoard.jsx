import "./GameBoard.css";

export default function GameBoard({ children }) {
  return <div className="game-board">{children}</div>;
}
