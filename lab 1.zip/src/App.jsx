import StartPage from "./pages/StartPage/StartPage";
// import GamePage from "./pages/GamePage/GamePage";
// import ResultsPage from "./pages/ResultsPage/ResultsPage";

function App() {
  // Тимчасово показуємо стартову сторінку.
  // Роутингу та бізнес-логіки в каркасі немає.
  return <StartPage />;
}

export default App;
