import Header from "../../components/Header/Header";
import PlayerCard from "../../components/PlayerCard/PlayerCard";
import GameBoard from "../../components/GameBoard/GameBoard";
import Button from "../../components/Button/Button";
import "./GamePage.css";

export default function GamePage() {
  const cells = ["X", "", "O", "", "X", "", "O", "", ""];

  return (
    <main className="page game-page">
      <Header />
      <section className="game-content">
        <div className="players">
          <PlayerCard name="Гравець X" symbol="X" active />
          <PlayerCard name="Гравець O" symbol="O" />
        </div>

        <p className="turn">Хід гравця: <strong>X</strong></p>

        <GameBoard>
          {cells.map((value, index) => (
            <div key={index} className="game-cell-wrapper">
              {/* Placeholder: клітинка без ігрової логіки */}
              <span>{value}</span>
            </div>
          ))}
        </GameBoard>

        <Button variant="secondary">Нова гра</Button>
      </section>
    </main>
  );
}
