import Header from "../../components/Header/Header";
import Button from "../../components/Button/Button";
import "./StartPage.css";

export default function StartPage() {
  return (
    <main className="page start-page">
      <Header />
      <section className="start-content">
        <p className="eyebrow">GAME</p>
        <h1>Хрестики-нулики</h1>
        <p className="subtitle">Класична гра для двох гравців</p>
        <Button>Грати</Button>
        <div className="placeholder">Стартовий екран</div>
      </section>
    </main>
  );
}
