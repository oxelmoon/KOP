import Header from "../../components/Header/Header";
import ResultCard from "../../components/ResultCard/ResultCard";
import Button from "../../components/Button/Button";
import "./ResultsPage.css";

export default function ResultsPage() {
  return (
    <main className="page results-page">
      <Header />
      <section className="results-content">
        <p className="eyebrow">РЕЗУЛЬТАТ</p>
        <ResultCard winner="Гравець X" scoreX="3" scoreO="1" />

        <div className="results-actions">
          <Button>Грати знову</Button>
          <Button variant="secondary">На старт</Button>
        </div>
      </section>
    </main>
  );
}
